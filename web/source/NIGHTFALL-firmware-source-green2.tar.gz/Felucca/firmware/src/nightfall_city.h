/* SPDX-License-Identifier: GPL-3.0-only
 * NIGHTFALL CITY: bounded integer note-to-pillar mapping for the FM-1 LCD.
 * Kept independent of the renderer so it can be tested on a host compiler. */
#ifndef NIGHTFALL_CITY_H
#define NIGHTFALL_CITY_H
#include <stdint.h>

#define NF_CITY_COLS 27u
typedef struct {
    uint8_t height[NF_CITY_COLS];
    uint8_t energy[NF_CITY_COLS];
    uint8_t held[NF_CITY_COLS];
} nf_city_t;

static void nf_city_clear(nf_city_t *city)
{
    uint32_t i;
    for (i = 0; i < NF_CITY_COLS; i++)
        city->height[i] = city->energy[i] = city->held[i] = 0;
}

/* The viewport follows the current 27-key octave. Notes outside it land at
 * the nearest edge; a transposed chord still creates a pillar for each note. */
static uint32_t nf_city_column(uint32_t note, int32_t base)
{
    int32_t column = (int32_t)note - base;
    return column < 0 ? 0u : column >= (int32_t)NF_CITY_COLS ? NF_CITY_COLS - 1u : (uint32_t)column;
}

static void nf_city_note(nf_city_t *city, uint32_t note, uint32_t velocity,
                         uint32_t envelope, uint32_t gate, int32_t base)
{
    uint32_t column, height, energy;
    if (note > 127u || !velocity)
        return;
    column = nf_city_column(note, base);
    height = 13u + note * 72u / 127u;  /* roof rises with absolute pitch */
    if (envelope > 32767u) envelope = 32767u;
    energy = velocity * envelope / 32767u;
    if (gate && energy < velocity / 4u) energy = velocity / 4u;
    if (height > city->height[column]) city->height[column] = (uint8_t)height;
    if (energy > city->energy[column]) city->energy[column] = (uint8_t)energy;
    if (gate) city->held[column] = 1;
}
#endif
